GM_Convert_Game
===============

This program converts game executables created with version 6.0 or 6.1
of Game Maker into a version that also runs under Windows Vista. Note
that games created with other versions of Game Maker do run under
Vista and, hence, need not be converted.

To use, start the program. Next drag the game executable on the form or
press the button to convert the game. The original executable is renamed
by adding _orig to the file name and the new adapted game executable is 
saved under the original name. 

Please note that this program is provided AS IS without any warranty. It
is just a quick hack and should be used with care. Always first make a
copy of your game.

Please realise that you are not allowed to redistribute converted games
unless you are the creator or copyright holder of the original game.

WE STRONGLY RECOMMEND YOU THAT IF YOU PLACE A VERSION 6.0 or 6.1 GAME
ON WWW.YOYOGAMES.COM THAT YOU FIRST RUN THIS TOOL TO MAKE IT VISTA
COMPATIBLE. IF YOUR GAME IS ALREADY THERE, PLEASE CONSIDER REPLACING
IT.

Mark Overmars




